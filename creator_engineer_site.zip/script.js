document.addEventListener("DOMContentLoaded", () => {
    console.log("Site loaded successfully!");
});
